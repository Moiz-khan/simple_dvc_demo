from setuptools import setup, find_packages

setup(
    name ="src",
    version="0.0.1",
    description="it is a wine package",
    author="Moiz-khan",
    packages=find_packages(),
    license="MIT"
)